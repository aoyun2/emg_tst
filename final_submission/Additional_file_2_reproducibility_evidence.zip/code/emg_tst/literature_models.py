from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class _PublishedEmgChannelBlock(nn.Module):
    """Per-channel CNN block released with Mollahossein et al. (2025)."""

    def __init__(self) -> None:
        super().__init__()
        self.conv1 = nn.Conv1d(1, 20, kernel_size=11, padding=5)
        self.conv2 = nn.Conv1d(20, 20, kernel_size=11, padding=5)
        self.dropout = nn.Dropout(0.5)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = F.elu(self.conv1(x))
        z = F.max_pool1d(z, kernel_size=2, stride=2)
        z = F.elu(self.conv2(z))
        return self.dropout(z)


class _PublishedEmgFrontend(nn.Module):
    """Four-channel EMG frontend from the authors' public architecture notebook."""

    def __init__(self, n_emg: int = 4) -> None:
        super().__init__()
        if int(n_emg) != 4:
            raise ValueError("The published architecture requires exactly four EMG channels.")
        self.n_emg = 4
        self.channel_blocks = nn.ModuleList([_PublishedEmgChannelBlock() for _ in range(4)])
        self.fusion_conv1 = nn.Conv1d(80, 20, kernel_size=11, padding=5)
        self.fusion_conv2 = nn.Conv1d(20, 20, kernel_size=11, padding=5)
        self.fusion_dropout = nn.Dropout(0.5)

    def forward(self, emg: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if emg.ndim != 3 or int(emg.shape[2]) != self.n_emg:
            raise ValueError(f"Expected [B,T,4] EMG input, received {tuple(emg.shape)}")
        channel_features = [
            block(emg[:, :, i : i + 1].transpose(1, 2))
            for i, block in enumerate(self.channel_blocks)
        ]
        fused = torch.cat(channel_features, dim=1)
        fused = F.elu(self.fusion_conv1(fused))
        fused = F.max_pool1d(fused, kernel_size=2, stride=2)
        fused = self.fusion_dropout(F.elu(self.fusion_conv2(fused)))

        # The released DIC network pools each channel a second time before
        # attention so it has the same temporal length as the fused stream.
        attended_channels = torch.stack(
            [F.max_pool1d(z, kernel_size=2, stride=2).transpose(1, 2) for z in channel_features],
            dim=2,
        )
        return fused.transpose(1, 2), attended_channels


class MollahosseinSic(nn.Module):
    """Published single-input (four-channel EMG) CNN-LSTM network."""

    def __init__(self, *, n_emg: int = 4) -> None:
        super().__init__()
        self.frontend = _PublishedEmgFrontend(n_emg=n_emg)
        self.lstm1 = nn.LSTM(input_size=20, hidden_size=32, batch_first=True)
        self.lstm2 = nn.LSTM(input_size=32, hidden_size=64, batch_first=True)
        self.output = nn.Linear(64, 1)

    def forward(self, emg: torch.Tensor) -> torch.Tensor:
        fused, _ = self.frontend(emg)
        z, _ = self.lstm1(fused)
        z, _ = self.lstm2(z)
        return self.output(z[:, -1, :])[:, 0]


class _BahdanauChannelAttention(nn.Module):
    """Bahdanau attention over four muscle channels at each time point."""

    def __init__(self, *, query_size: int = 32, feature_size: int = 20, attention_size: int = 10) -> None:
        super().__init__()
        self.query = nn.Linear(query_size, attention_size)
        self.feature = nn.Linear(feature_size, attention_size)
        self.score = nn.Linear(attention_size, 1)

    def forward(self, query: torch.Tensor, channels: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        # query: [B,32]; channels: [B,T,4,20]
        q = self.query(query)[:, None, None, :]
        h = self.feature(channels)
        scores = self.score(torch.tanh(q + h)).squeeze(-1)
        weights = torch.softmax(scores, dim=2)
        context = torch.sum(weights[:, :, :, None] * channels, dim=2)
        return context, weights


class MollahosseinAttentionCnnLstm(nn.Module):
    """Published DIC attention CNN-LSTM adapted to the original six thigh-IMU inputs.

    The four EMG branches, convolution sizes, pooling, dropout, attention size,
    and recurrent widths match the authors' released notebook. The paper's
    historical-knee-angle branch is replaced by the six thigh-IMU channels used
    in the original prosthetic-regression experiment.
    """

    def __init__(self, *, n_emg: int = 4, n_imu: int = 6) -> None:
        super().__init__()
        self.n_emg = int(n_emg)
        self.n_imu = int(n_imu)
        if self.n_emg != 4:
            raise ValueError("The published architecture requires exactly four EMG channels.")
        if self.n_imu < 1:
            raise ValueError("At least one non-EMG input is required.")

        self.frontend = _PublishedEmgFrontend(n_emg=self.n_emg)
        self.imu_lstm = nn.LSTM(input_size=self.n_imu, hidden_size=32, batch_first=True)
        self.attention = _BahdanauChannelAttention()
        self.lstm1 = nn.LSTM(input_size=40, hidden_size=32, batch_first=True)
        self.lstm2 = nn.LSTM(input_size=32, hidden_size=64, batch_first=True)
        self.output = nn.Linear(64, 1)

    def initialize_frontend_from_sic(self, sic: MollahosseinSic) -> None:
        self.frontend.load_state_dict(sic.frontend.state_dict(), strict=True)
        self.lstm2.load_state_dict(sic.lstm2.state_dict(), strict=True)
        self.output.load_state_dict(sic.output.state_dict(), strict=True)
        with torch.no_grad():
            # The DIC first LSTM receives [attention context, fused EMG]. Copy
            # the SIC's fused-EMG input weights into the corresponding half.
            self.lstm1.weight_ih_l0[:, 20:].copy_(sic.lstm1.weight_ih_l0)
            self.lstm1.weight_hh_l0.copy_(sic.lstm1.weight_hh_l0)
            self.lstm1.bias_ih_l0.copy_(sic.lstm1.bias_ih_l0)
            self.lstm1.bias_hh_l0.copy_(sic.lstm1.bias_hh_l0)

    def forward(self, x: torch.Tensor, *, return_attention: bool = False):
        if x.ndim != 3 or int(x.shape[2]) != self.n_emg + self.n_imu:
            raise ValueError(
                f"Expected [B,T,{self.n_emg + self.n_imu}] input, received {tuple(x.shape)}"
            )
        if int(x.shape[1]) % 4 != 0:
            raise ValueError("The input length must be divisible by four.")

        emg = x[:, :, : self.n_emg]
        imu = x[:, :, self.n_emg :]
        fused_emg, channel_features = self.frontend(emg)

        # Exact decimation by non-overlapping averaging; no interpolation.
        imu_pooled = F.avg_pool1d(imu.transpose(1, 2), kernel_size=4, stride=4).transpose(1, 2)
        imu_state, _ = self.imu_lstm(imu_pooled)
        context, weights = self.attention(imu_state[:, -1, :], channel_features)

        z = torch.cat([context, fused_emg], dim=2)
        z, _ = self.lstm1(z)
        z, _ = self.lstm2(z)
        pred = self.output(z[:, -1, :])[:, 0]
        if return_attention:
            return pred, weights
        return pred


class SunCnnBiLstm(nn.Module):
    """Feature-based CNN-BiLSTM described by Sun et al. (2022).

    The source method uses 20 consecutive feature vectors. The feature count is
    configurable only so the same published network can later be evaluated on
    the original Georgia Tech sensor panel without changing its architecture.
    """

    def __init__(self, *, n_features: int = 10, sequence_length: int = 400) -> None:
        super().__init__()
        self.n_features = int(n_features)
        self.sequence_length = int(sequence_length)
        self.conv = nn.Conv1d(self.n_features, 64, kernel_size=1)
        self.batch_norm = nn.BatchNorm1d(64)
        self.dropout = nn.Dropout(0.5)
        self.lstm = nn.LSTM(
            input_size=64,
            hidden_size=64,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.5,
        )
        self.output = nn.Linear(self.sequence_length * 128, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 3 or tuple(x.shape[1:]) != (self.sequence_length, self.n_features):
            raise ValueError(
                f"Expected [B,{self.sequence_length},{self.n_features}], received {tuple(x.shape)}"
            )
        z = self.dropout(F.relu(self.batch_norm(self.conv(x.transpose(1, 2)))))
        z, _ = self.lstm(z.transpose(1, 2))
        return F.relu(self.output(z.reshape(int(z.shape[0]), -1)))[:, 0]


class SunRawCnnBiLstm(SunCnnBiLstm):
    """Backward-compatible name used by the superseded Georgia Tech V3 run."""


class KinPreNetGt(nn.Module):
    """KinPreNet topology adapted to the original Georgia Tech sensor panel.

    Yi et al. used a three-layer, 40-unit LSTM to extract one learned feature
    per EMG channel, followed by a second three-layer, 40-unit LSTM and
    40-to-80-to-1 readout for knee-angle prediction. Their nine EMG channels
    and single IMU-derived current knee angle are replaced here by the four
    original Georgia Tech EMG channels and six original thigh-IMU channels.
    No target-derived knee angle is introduced as an input.
    """

    def __init__(self, *, n_emg: int = 4, n_imu: int = 6, hidden_size: int = 40) -> None:
        super().__init__()
        self.n_emg = int(n_emg)
        self.n_imu = int(n_imu)
        self.hidden_size = int(hidden_size)
        if self.n_emg != 4 or self.n_imu != 6:
            raise ValueError("The Georgia Tech adaptation requires four EMG and six thigh-IMU channels.")

        self.emg_lstm = nn.LSTM(
            input_size=self.n_emg,
            hidden_size=self.hidden_size,
            num_layers=3,
            batch_first=True,
        )
        self.emg_projection = nn.Linear(self.hidden_size, self.n_emg)
        self.predictor_lstm = nn.LSTM(
            input_size=self.n_emg + self.n_imu,
            hidden_size=self.hidden_size,
            num_layers=3,
            batch_first=True,
        )
        self.readout_hidden = nn.Linear(self.hidden_size, 80)
        self.readout = nn.Linear(80, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 3 or int(x.shape[2]) != self.n_emg + self.n_imu:
            raise ValueError(
                f"Expected [B,T,{self.n_emg + self.n_imu}] input, received {tuple(x.shape)}"
            )
        emg_state, _ = self.emg_lstm(x[:, :, : self.n_emg])
        emg_features = self.emg_projection(emg_state)
        predictor_input = torch.cat([emg_features, x[:, :, self.n_emg :]], dim=2)
        predictor_state, _ = self.predictor_lstm(predictor_input)
        hidden = self.readout_hidden(predictor_state[:, -1, :])
        return self.readout(hidden)[:, 0]

    def optimizer_parameter_groups(
        self, *, extractor_learning_rate: float, predictor_learning_rate: float
    ) -> list[dict]:
        extractor = list(self.emg_lstm.parameters()) + list(self.emg_projection.parameters())
        predictor = (
            list(self.predictor_lstm.parameters())
            + list(self.readout_hidden.parameters())
            + list(self.readout.parameters())
        )
        return [
            {"params": extractor, "lr": float(extractor_learning_rate)},
            {"params": predictor, "lr": float(predictor_learning_rate)},
        ]


class KinPreNetGait120(nn.Module):
    """Published KinPreNet topology for Gait120's 12 sEMG channels.

    Yi et al.'s kinematic input is the measured current knee angle. Gait120
    supplies the same kinematic quantity from synchronized OpenSim inverse
    kinematics rather than an IMU reconstruction. The recurrent depth, hidden
    size, channel projection, and readout dimensions follow KinPreNet.
    """

    def __init__(self, *, n_emg: int = 12, n_kinematic: int = 1, hidden_size: int = 40) -> None:
        super().__init__()
        self.n_emg = int(n_emg)
        self.n_kinematic = int(n_kinematic)
        self.hidden_size = int(hidden_size)
        if self.n_emg != 12 or self.n_kinematic != 1 or self.hidden_size != 40:
            raise ValueError("The prespecified Gait120 KinPreNet requires 12+1 inputs and 40 units")
        self.emg_lstm = nn.LSTM(
            input_size=self.n_emg,
            hidden_size=self.hidden_size,
            num_layers=3,
            batch_first=True,
        )
        self.emg_projection = nn.Linear(self.hidden_size, self.n_emg)
        self.predictor_lstm = nn.LSTM(
            input_size=self.n_emg + self.n_kinematic,
            hidden_size=self.hidden_size,
            num_layers=3,
            batch_first=True,
        )
        self.readout_hidden = nn.Linear(self.hidden_size, 80)
        self.readout = nn.Linear(80, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 3 or int(x.shape[2]) != self.n_emg + self.n_kinematic:
            raise ValueError(
                f"Expected [B,T,{self.n_emg + self.n_kinematic}] input, "
                f"received {tuple(x.shape)}"
            )
        emg_state, _ = self.emg_lstm(x[:, :, : self.n_emg])
        emg_features = self.emg_projection(emg_state)
        predictor_input = torch.cat([emg_features, x[:, :, self.n_emg :]], dim=2)
        predictor_state, _ = self.predictor_lstm(predictor_input)
        hidden = self.readout_hidden(predictor_state[:, -1, :])
        return self.readout(hidden)[:, 0]

    def optimizer_parameter_groups(
        self, *, extractor_learning_rate: float, predictor_learning_rate: float
    ) -> list[dict]:
        extractor = list(self.emg_lstm.parameters()) + list(self.emg_projection.parameters())
        predictor = (
            list(self.predictor_lstm.parameters())
            + list(self.readout_hidden.parameters())
            + list(self.readout.parameters())
        )
        return [
            {"params": extractor, "lr": float(extractor_learning_rate)},
            {"params": predictor, "lr": float(predictor_learning_rate)},
        ]


def build_literature_model(name: str, *, sequence_length: int = 400) -> nn.Module:
    key = str(name).strip().lower()
    if key == "attention_cnn_lstm":
        return MollahosseinAttentionCnnLstm(n_emg=4, n_imu=6)
    if key == "sun_cnn_bilstm":
        return SunCnnBiLstm(n_features=10, sequence_length=int(sequence_length))
    if key == "kinprenet_gt":
        return KinPreNetGt(n_emg=4, n_imu=6, hidden_size=40)
    raise ValueError(f"Unknown literature model {name!r}")
