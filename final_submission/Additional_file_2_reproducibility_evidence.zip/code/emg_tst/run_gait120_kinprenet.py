from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import random
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

import numpy as np
import torch
from torch import nn

from emg_tst.literature_models import KinPreNetGait120


VERSION = "GAIT120_KINPRENET_100MS_V1"
CACHE_VERSION = "GAIT120_CAUSAL_RAW_LEVEL_WALKING_V2"
SEED = 42
N_EMG = 12
INPUT_FRAMES = 10
HORIZON_FRAMES = 10
TRAIN_TRIALS = (1, 2, 3)
VALIDATION_TRIALS = (4,)
TEST_TRIALS = (5,)
BATCH_SIZE = 128
MAX_EPOCHS = 30
EXTRACTOR_LR = 1.0e-3
PREDICTOR_LR = 1.0e-4
WEIGHT_DECAY = 1.0e-5
LR_DECAY_EPOCH = 20
LR_DECAY_FACTOR = 0.8
BOOTSTRAP_DRAWS = 100_000
RANDOMIZATION_DRAWS = 1_000_000


def _json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(type(value).__name__)


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True, default=_json_default),
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _atomic_torch(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(value, temporary)
    os.replace(temporary, path)


def _atomic_npz(path: Path, **arrays: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as stream:
        np.savez_compressed(stream, **arrays)
    os.replace(temporary, path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _set_determinism(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def _model_state_digest(model: nn.Module) -> str:
    digest = hashlib.sha256()
    for name, value in model.state_dict().items():
        digest.update(name.encode("utf-8"))
        digest.update(value.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


@dataclass(frozen=True)
class ExampleSet:
    x: np.ndarray
    y_standardized: np.ndarray
    y_deg: np.ndarray
    target_mean_deg: np.ndarray
    target_std_deg: np.ndarray
    subject_number: np.ndarray
    trial_index: np.ndarray
    input_end_frame: np.ndarray
    target_frame: np.ndarray

    def __len__(self) -> int:
        return int(self.y_deg.size)


def _load_cache(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as stored:
        data = {key: np.asarray(stored[key]) for key in stored.files}
    if str(data["cache_version"].reshape(())) != CACHE_VERSION:
        raise RuntimeError(f"Unexpected Gait120 cache version in {path}")
    if int(data["motion_hz"].reshape(())) != 100:
        raise RuntimeError(f"Unexpected motion rate in {path}")
    emg = np.asarray(data["emg_frame_native_value"], dtype=np.float32)
    knee = np.asarray(data["knee_flexion_deg"], dtype=np.float32).reshape(-1)
    trial = np.asarray(data["trial_index"], dtype=np.int16).reshape(-1)
    frame = np.asarray(data["frame_index"], dtype=np.int16).reshape(-1)
    if emg.shape != (knee.size, N_EMG) or trial.size != knee.size or frame.size != knee.size:
        raise RuntimeError(f"Malformed Gait120 cache arrays in {path}")
    if not np.all(np.isfinite(emg)) or not np.all(np.isfinite(knee)):
        raise RuntimeError(f"Non-finite cached values in {path}")
    return data


def _training_scaler(data: dict[str, np.ndarray]) -> dict[str, np.ndarray | float]:
    trial = np.asarray(data["trial_index"], dtype=np.int16).reshape(-1)
    rows = np.flatnonzero(np.isin(trial, TRAIN_TRIALS))
    if rows.size < 1:
        raise RuntimeError("No participant calibration rows")
    emg = np.asarray(data["emg_frame_native_value"], dtype=np.float64)[rows]
    knee = np.asarray(data["knee_flexion_deg"], dtype=np.float64).reshape(-1)[rows]
    emg_mean = np.mean(emg, axis=0)
    emg_std = np.maximum(np.std(emg, axis=0), 1.0e-8)
    knee_mean = float(np.mean(knee))
    knee_std = max(float(np.std(knee)), 1.0e-8)
    return {
        "emg_mean": emg_mean.astype(np.float32),
        "emg_std": emg_std.astype(np.float32),
        "knee_mean": knee_mean,
        "knee_std": knee_std,
    }


def _examples_for_trials(
    *,
    data: dict[str, np.ndarray],
    subject_number: int,
    trials: tuple[int, ...],
    scaler: dict[str, np.ndarray | float],
) -> ExampleSet:
    emg = np.asarray(data["emg_frame_native_value"], dtype=np.float32)
    knee = np.asarray(data["knee_flexion_deg"], dtype=np.float32).reshape(-1)
    trial_all = np.asarray(data["trial_index"], dtype=np.int16).reshape(-1)
    frame_all = np.asarray(data["frame_index"], dtype=np.int16).reshape(-1)
    emg_mean = np.asarray(scaler["emg_mean"], dtype=np.float32)
    emg_std = np.asarray(scaler["emg_std"], dtype=np.float32)
    knee_mean = float(scaler["knee_mean"])
    knee_std = float(scaler["knee_std"])

    xs: list[np.ndarray] = []
    ys: list[float] = []
    y_deg: list[float] = []
    trial_out: list[int] = []
    input_end: list[int] = []
    target_frame: list[int] = []
    for trial_index in trials:
        rows = np.flatnonzero(trial_all == trial_index)
        if rows.size < INPUT_FRAMES + HORIZON_FRAMES + 1:
            raise RuntimeError(f"S{subject_number:03d} trial {trial_index} is too short")
        if not np.array_equal(frame_all[rows], np.arange(rows.size)):
            raise RuntimeError("Cached trial frame indices are not consecutive")
        for local_end in range(INPUT_FRAMES - 1, rows.size - HORIZON_FRAMES):
            window_rows = rows[local_end - INPUT_FRAMES + 1 : local_end + 1]
            target_row = rows[local_end + HORIZON_FRAMES]
            emg_window = (emg[window_rows] - emg_mean[None, :]) / emg_std[None, :]
            knee_window = (knee[window_rows] - knee_mean) / knee_std
            xs.append(
                np.concatenate([emg_window, knee_window[:, None]], axis=1).astype(np.float32)
            )
            target = float(knee[target_row])
            ys.append((target - knee_mean) / knee_std)
            y_deg.append(target)
            trial_out.append(int(trial_index))
            input_end.append(int(local_end))
            target_frame.append(int(local_end + HORIZON_FRAMES))
    n = len(xs)
    return ExampleSet(
        x=np.stack(xs).astype(np.float32),
        y_standardized=np.asarray(ys, dtype=np.float32),
        y_deg=np.asarray(y_deg, dtype=np.float32),
        target_mean_deg=np.full(n, knee_mean, dtype=np.float32),
        target_std_deg=np.full(n, knee_std, dtype=np.float32),
        subject_number=np.full(n, subject_number, dtype=np.int16),
        trial_index=np.asarray(trial_out, dtype=np.int16),
        input_end_frame=np.asarray(input_end, dtype=np.int16),
        target_frame=np.asarray(target_frame, dtype=np.int16),
    )


def _combine(sets: list[ExampleSet]) -> ExampleSet:
    if not sets:
        raise ValueError("No example sets to combine")
    return ExampleSet(
        **{
            field: np.concatenate([getattr(item, field) for item in sets], axis=0)
            for field in ExampleSet.__dataclass_fields__
        }
    )


def _build_examples(
    cache_dir: Path, subject_numbers: list[int]
) -> tuple[ExampleSet, ExampleSet, ExampleSet, dict[str, dict[str, Any]]]:
    train: list[ExampleSet] = []
    validation: list[ExampleSet] = []
    test: list[ExampleSet] = []
    scalers: dict[str, dict[str, Any]] = {}
    for number in subject_numbers:
        subject = f"S{number:03d}"
        data = _load_cache(cache_dir / f"{subject}.npz")
        stored_subject = str(np.asarray(data["subject"]).reshape(()))
        if stored_subject != subject:
            raise RuntimeError(f"Cache subject mismatch: expected {subject}, got {stored_subject}")
        available_trials = set(
            np.asarray(data["trial_index"], dtype=np.int16).reshape(-1).tolist()
        )
        required = set(TRAIN_TRIALS + VALIDATION_TRIALS + TEST_TRIALS)
        if not required.issubset(available_trials):
            raise RuntimeError(f"{subject} lacks required trials {sorted(required - available_trials)}")
        scaler = _training_scaler(data)
        scalers[subject] = {
            "emg_mean": np.asarray(scaler["emg_mean"]).tolist(),
            "emg_std": np.asarray(scaler["emg_std"]).tolist(),
            "knee_mean": float(scaler["knee_mean"]),
            "knee_std": float(scaler["knee_std"]),
        }
        train.append(
            _examples_for_trials(
                data=data, subject_number=number, trials=TRAIN_TRIALS, scaler=scaler
            )
        )
        validation.append(
            _examples_for_trials(
                data=data,
                subject_number=number,
                trials=VALIDATION_TRIALS,
                scaler=scaler,
            )
        )
        test.append(
            _examples_for_trials(
                data=data, subject_number=number, trials=TEST_TRIALS, scaler=scaler
            )
        )
    return _combine(train), _combine(validation), _combine(test), scalers


@torch.no_grad()
def _predict(
    model: nn.Module,
    examples: ExampleSet,
    *,
    device: torch.device,
    no_emg: bool,
) -> np.ndarray:
    model.eval()
    output: list[np.ndarray] = []
    for first in range(0, len(examples), 1024):
        x = torch.from_numpy(examples.x[first : first + 1024]).to(device)
        if no_emg:
            x = x.clone()
            x[:, :, :N_EMG] = 0.0
        with torch.autocast(
            device_type=device.type, dtype=torch.float16, enabled=device.type == "cuda"
        ):
            predicted = model(x)
        output.append(predicted.float().cpu().numpy())
    standardized = np.concatenate(output).astype(np.float32)
    return (
        standardized * examples.target_std_deg + examples.target_mean_deg
    ).astype(np.float32)


def _participant_metrics(examples: ExampleSet, prediction_deg: np.ndarray) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for subject_number in np.unique(examples.subject_number).tolist():
        keep = examples.subject_number == subject_number
        residual = np.asarray(prediction_deg[keep], dtype=np.float64) - np.asarray(
            examples.y_deg[keep], dtype=np.float64
        )
        rows.append(
            {
                "subject": f"S{int(subject_number):03d}",
                "rmse_deg": float(np.sqrt(np.mean(np.square(residual)))),
                "mae_deg": float(np.mean(np.abs(residual))),
                "n_examples": int(np.sum(keep)),
            }
        )
    all_residual = np.asarray(prediction_deg, dtype=np.float64) - np.asarray(
        examples.y_deg, dtype=np.float64
    )
    return {
        "participants": rows,
        "mean_participant_rmse_deg": float(np.mean([row["rmse_deg"] for row in rows])),
        "pooled_rmse_deg": float(np.sqrt(np.mean(np.square(all_residual)))),
        "pooled_mae_deg": float(np.mean(np.abs(all_residual))),
        "n_examples": len(examples),
    }


def _train_condition(
    *,
    condition: str,
    train: ExampleSet,
    validation: ExampleSet,
    test: ExampleSet,
    out_dir: Path,
    device: torch.device,
    max_epochs: int,
    progress: Callable[[str, int, dict[str, Any]], None],
) -> tuple[dict[str, Any], str]:
    no_emg = condition == "no_emg"
    _set_determinism(SEED)
    model = KinPreNetGait120().to(device)
    initial_digest = _model_state_digest(model)
    optimizer = torch.optim.Adam(
        model.optimizer_parameter_groups(
            extractor_learning_rate=EXTRACTOR_LR,
            predictor_learning_rate=PREDICTOR_LR,
        ),
        weight_decay=WEIGHT_DECAY,
    )
    loss_fn = nn.MSELoss()
    history: list[dict[str, Any]] = []
    best_epoch = -1
    best_validation = float("inf")
    best_path = out_dir / "best.pt"

    for epoch in range(1, max_epochs + 1):
        if epoch == LR_DECAY_EPOCH:
            for group in optimizer.param_groups:
                group["lr"] *= LR_DECAY_FACTOR
        model.train()
        generator = torch.Generator(device="cpu")
        generator.manual_seed(SEED + epoch)
        order = torch.randperm(len(train), generator=generator).numpy()
        total_loss = 0.0
        count = 0
        for first in range(0, len(order), BATCH_SIZE):
            index = order[first : first + BATCH_SIZE]
            x = torch.from_numpy(train.x[index]).to(device)
            y = torch.from_numpy(train.y_standardized[index]).to(device)
            if no_emg:
                x = x.clone()
                x[:, :, :N_EMG] = 0.0
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(
                device_type=device.type, dtype=torch.float16, enabled=device.type == "cuda"
            ):
                predicted = model(x)
                loss = loss_fn(predicted, y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()
            batch_n = int(index.size)
            total_loss += float(loss.detach().cpu()) * batch_n
            count += batch_n

        validation_prediction = _predict(
            model, validation, device=device, no_emg=no_emg
        )
        validation_metrics = _participant_metrics(validation, validation_prediction)
        row = {
            "epoch": epoch,
            "train_standardized_mse": total_loss / max(count, 1),
            "validation": validation_metrics,
            "extractor_learning_rate": float(optimizer.param_groups[0]["lr"]),
            "predictor_learning_rate": float(optimizer.param_groups[1]["lr"]),
        }
        history.append(row)
        payload = {
            "version": VERSION,
            "condition": condition,
            "epoch": epoch,
            "state_dict": model.state_dict(),
            "initial_state_sha256": initial_digest,
        }
        checkpoint_path = out_dir / "checkpoints" / f"epoch_{epoch:03d}.pt"
        _atomic_torch(checkpoint_path, payload)
        validation_score = float(validation_metrics["mean_participant_rmse_deg"])
        if validation_score < best_validation:
            best_validation = validation_score
            best_epoch = epoch
            _atomic_torch(best_path, payload)
        _atomic_json(out_dir / "history.json", {"epochs": history})
        progress(condition, epoch, row)

    if best_epoch < 1 or not best_path.exists():
        raise RuntimeError(f"No validation checkpoint selected for {condition}")
    payload = torch.load(best_path, map_location="cpu", weights_only=False)
    model.load_state_dict(payload["state_dict"], strict=True)
    test_prediction = _predict(model, test, device=device, no_emg=no_emg)
    test_metrics = _participant_metrics(test, test_prediction)
    result = {
        "condition": condition,
        "initial_state_sha256": initial_digest,
        "best_epoch": best_epoch,
        "best_validation_mean_participant_rmse_deg": best_validation,
        "test": test_metrics,
    }
    _atomic_json(out_dir / "result.json", result)
    _atomic_npz(
        out_dir / "best_test_predictions.npz",
        prediction_deg=test_prediction,
        target_deg=test.y_deg,
        subject_number=test.subject_number,
        trial_index=test.trial_index,
        input_end_frame=test.input_end_frame,
        target_frame=test.target_frame,
        best_epoch=np.asarray(best_epoch, dtype=np.int16),
    )
    return result, initial_digest


def _paired_statistics(
    fused: dict[str, Any], no_emg: dict[str, Any], *, require_gate: bool
) -> dict[str, Any]:
    fused_rows = {row["subject"]: row for row in fused["test"]["participants"]}
    no_emg_rows = {row["subject"]: row for row in no_emg["test"]["participants"]}
    if set(fused_rows) != set(no_emg_rows):
        raise RuntimeError("Paired conditions have different test participants")
    subjects = sorted(fused_rows)
    effects = np.asarray(
        [no_emg_rows[s]["rmse_deg"] - fused_rows[s]["rmse_deg"] for s in subjects],
        dtype=np.float64,
    )
    rng = np.random.default_rng(20260824)
    bootstrap_means: list[np.ndarray] = []
    for first in range(0, BOOTSTRAP_DRAWS, 2_000):
        draws = min(2_000, BOOTSTRAP_DRAWS - first)
        index = rng.integers(0, effects.size, size=(draws, effects.size))
        bootstrap_means.append(np.mean(effects[index], axis=1))
    boot = np.concatenate(bootstrap_means)
    lower, upper = np.quantile(boot, [0.025, 0.975]).tolist()

    observed = abs(float(np.mean(effects)))
    exceed = 0
    completed = 0
    for _ in range(0, RANDOMIZATION_DRAWS, 10_000):
        draws = min(10_000, RANDOMIZATION_DRAWS - completed)
        signs = rng.integers(0, 2, size=(draws, effects.size), dtype=np.int8) * 2 - 1
        permuted = np.abs(np.mean(signs * effects[None, :], axis=1))
        exceed += int(np.sum(permuted >= observed - 1.0e-15))
        completed += draws
    p_value = (exceed + 1.0) / (completed + 1.0)
    positive = int(np.sum(effects > 0.0))
    gate = bool(
        float(np.mean(effects)) > 0.0
        and float(lower) > 0.0
        and p_value <= 0.05
        and positive > effects.size / 2
    )
    return {
        "definition": "no-sEMG participant test RMSE minus fused participant test RMSE",
        "subjects": subjects,
        "improvement_deg": effects,
        "mean_improvement_deg": float(np.mean(effects)),
        "median_improvement_deg": float(np.median(effects)),
        "bootstrap_95pct_ci_deg": [float(lower), float(upper)],
        "two_sided_randomization_p": float(p_value),
        "randomization_draws": completed,
        "positive_participants": positive,
        "participant_count": int(effects.size),
        "fused_mean_participant_rmse_deg": float(
            fused["test"]["mean_participant_rmse_deg"]
        ),
        "no_emg_mean_participant_rmse_deg": float(
            no_emg["test"]["mean_participant_rmse_deg"]
        ),
        "gate_applied": bool(require_gate),
        "passed": gate if require_gate else None,
    }


def _protocol(
    *,
    phase: str,
    subject_numbers: list[int],
    cache_dir: Path,
    max_epochs: int,
    root: Path,
    device: torch.device,
) -> dict[str, Any]:
    return {
        "version": VERSION,
        "phase": phase,
        "dataset": {
            "name": "Gait120",
            "source": "Boo et al. (2025), doi:10.1038/s41597-025-05391-0",
            "activity": "LevelWalking only",
            "subjects": [f"S{number:03d}" for number in subject_numbers],
            "train_trials": list(TRAIN_TRIALS),
            "validation_trials": list(VALIDATION_TRIALS),
            "test_trials": list(TEST_TRIALS),
            "cache_dir": str(cache_dir),
            "interpolation": "none",
            "emg_field": "raw sEMG with causal 20-500 Hz Butterworth filtering, rectification, trailing 250-sample RMS, and the final value in each synchronized 20-sample frame block",
        },
        "model": {
            "name": "KinPreNet-Gait120",
            "source": "Yi et al., doi:10.1109/TCSVT.2021.3071461",
            "topology": "three 40-unit EMG LSTMs, 40-to-12 projection, three 40-unit predictor LSTMs, and 40-to-80-to-1 readout",
            "paired_ablation": "same 13-input architecture; only the 12 standardized EMG inputs are zeroed in the no-sEMG condition",
        },
        "prediction": {
            "sample_hz": 100,
            "input_frames": INPUT_FRAMES,
            "input_ms": 10 * INPUT_FRAMES,
            "forecast_frames": HORIZON_FRAMES,
            "forecast_ms": 10 * HORIZON_FRAMES,
            "kinematic_input": "measured current and recent knee flexion angle",
            "target": "knee flexion angle 100 ms after the final input frame",
        },
        "training": {
            "seed": SEED,
            "batch_size": BATCH_SIZE,
            "max_epochs": max_epochs,
            "optimizer": "Adam",
            "loss": "mean squared error on participant-standardized knee angle",
            "extractor_learning_rate": EXTRACTOR_LR,
            "predictor_learning_rate": PREDICTOR_LR,
            "weight_decay": WEIGHT_DECAY,
            "lr_decay_epoch": LR_DECAY_EPOCH,
            "lr_decay_factor": LR_DECAY_FACTOR,
            "checkpoint_selection": "lowest mean participant validation RMSE, independently but identically applied to each condition",
            "calibration": "participant-specific means and standard deviations from trials 1-3 only",
        },
        "gate": {
            "unit": "participant",
            "effect": "no-sEMG test RMSE minus fused test RMSE",
            "mean_strictly_positive": True,
            "bootstrap_95pct_lower_strictly_positive": True,
            "two_sided_randomization_p_max": 0.05,
            "strict_majority_positive": True,
        },
        "software": {
            "python": platform.python_version(),
            "torch": torch.__version__,
            "cuda": torch.version.cuda,
            "device": str(device),
            "gpu": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
        },
        "code_sha256": {
            "runner": _sha256(Path(__file__).resolve()),
            "model": _sha256(root / "emg_tst" / "literature_models.py"),
            "native_loader": _sha256(root / "emg_tst" / "gait120_data.py"),
            "cache_export": _sha256(root / "emg_tst" / "preprocess_gait120.py"),
            "continuation": _sha256(root / "PUBLISHED_REPLICATION_CONTINUATION.md"),
        },
    }


def main() -> None:
    global INPUT_FRAMES, VERSION
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("smoke", "development", "confirmation"), required=True)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--development-run-dir", type=Path)
    parser.add_argument("--first-subject", type=int)
    parser.add_argument("--last-subject", type=int)
    parser.add_argument("--max-epochs", type=int)
    parser.add_argument("--input-frames", type=int, default=INPUT_FRAMES)
    args = parser.parse_args()

    INPUT_FRAMES = int(args.input_frames)
    if INPUT_FRAMES < 1:
        raise ValueError("input-frames must be positive")
    VERSION = f"GAIT120_KINPRENET_{INPUT_FRAMES}STEP_100MS_V2"

    root = Path(__file__).resolve().parents[1]
    cache_dir = args.cache_dir.resolve()
    run_dir = args.run_dir.resolve()
    if args.phase == "development":
        subject_numbers = list(range(1, 31))
    elif args.phase == "confirmation":
        subject_numbers = list(range(31, 121))
        if args.development_run_dir is None:
            raise ValueError("Confirmation requires --development-run-dir")
        development_summary_path = args.development_run_dir / "ablation_summary.json"
        if not development_summary_path.exists():
            raise RuntimeError("Development ablation summary is missing")
        development_summary = json.loads(
            development_summary_path.read_text(encoding="utf-8")
        )
        if not bool(development_summary.get("passed")):
            raise RuntimeError("Development did not pass; confirmation is locked")
    else:
        first = 1 if args.first_subject is None else int(args.first_subject)
        last = first if args.last_subject is None else int(args.last_subject)
        subject_numbers = list(range(first, last + 1))
    max_epochs = (
        (2 if args.phase == "smoke" else MAX_EPOCHS)
        if args.max_epochs is None
        else int(args.max_epochs)
    )
    if max_epochs < 1:
        raise ValueError("max_epochs must be positive")

    if not torch.cuda.is_available():
        raise RuntimeError("The definitive Gait120 training runner requires CUDA")
    device = torch.device("cuda:0")
    _set_determinism(SEED)
    protocol = _protocol(
        phase=args.phase,
        subject_numbers=subject_numbers,
        cache_dir=cache_dir,
        max_epochs=max_epochs,
        root=root,
        device=device,
    )
    run_dir.mkdir(parents=True, exist_ok=True)
    protocol_path = run_dir / "protocol.json"
    if protocol_path.exists():
        if json.loads(protocol_path.read_text(encoding="utf-8")) != protocol:
            raise RuntimeError("Existing run protocol differs from the executable protocol")
    else:
        _atomic_json(protocol_path, protocol)
    status_path = run_dir / "pipeline_status.json"

    def status(stage: str, **extra: Any) -> None:
        _atomic_json(
            status_path,
            {
                "version": VERSION,
                "phase": args.phase,
                "stage": stage,
                "updated_unix": time.time(),
                **extra,
            },
        )

    status("loading_cached_native_data")
    train, validation, test, scalers = _build_examples(cache_dir, subject_numbers)
    _atomic_json(
        run_dir / "data_audit.json",
        {
            "subjects": [f"S{number:03d}" for number in subject_numbers],
            "training_examples": len(train),
            "validation_examples": len(validation),
            "test_examples": len(test),
            "input_shape": list(train.x.shape[1:]),
            "scalers": scalers,
            "trial_leakage": False,
        },
    )

    def progress(condition: str, epoch: int, row: dict[str, Any]) -> None:
        status(
            "training",
            condition=condition,
            epoch=epoch,
            max_epochs=max_epochs,
            validation_mean_participant_rmse_deg=row["validation"][
                "mean_participant_rmse_deg"
            ],
        )

    results: dict[str, dict[str, Any]] = {}
    initial_digests: dict[str, str] = {}
    for condition in ("fused", "no_emg"):
        result, digest = _train_condition(
            condition=condition,
            train=train,
            validation=validation,
            test=test,
            out_dir=run_dir / condition,
            device=device,
            max_epochs=max_epochs,
            progress=progress,
        )
        results[condition] = result
        initial_digests[condition] = digest
    if initial_digests["fused"] != initial_digests["no_emg"]:
        raise RuntimeError("Paired model initializations differ")

    require_gate = args.phase in ("development", "confirmation")
    summary = _paired_statistics(
        results["fused"], results["no_emg"], require_gate=require_gate
    )
    summary["phase"] = args.phase
    summary["paired_initial_state_sha256"] = initial_digests["fused"]
    _atomic_json(run_dir / "ablation_summary.json", summary)
    status(
        "complete",
        passed=summary["passed"],
        mean_improvement_deg=summary["mean_improvement_deg"],
        bootstrap_95pct_ci_deg=summary["bootstrap_95pct_ci_deg"],
        two_sided_randomization_p=summary["two_sided_randomization_p"],
        positive_participants=summary["positive_participants"],
        participant_count=summary["participant_count"],
    )
    print(json.dumps(summary, indent=2, default=_json_default))


if __name__ == "__main__":
    main()
