Additional file 2: reproducibility evidence

This archive contains the exact derived prediction, matching, simulation, and
statistical records used in the manuscript. Raw Gait120 and MoCapAct files are
not redistributed. They remain available from the repositories cited in the
manuscript.

Contents
--------

prediction_confirmation/
  Prespecified 90-participant confirmation protocol, participant-level results,
  predictions, fitted ridge models, data audit, and sEMG ablation summary.

temporal_control/
  The aligned and 500-ms-shifted sEMG timing-control results.

accuracy_path/
  All seven prospectively selected training-data checkpoints (5%, 10%, 20%,
  40%, 60%, 80%, and 100%), including predictions and fitted models.

physics/
  The final level-walking protocol, complete 560-rollout summary, stable-match
  summary, zero-error controller check, and final pipeline status.

analysis/
  Machine-readable audit, window- and participant-level result tables,
  statistical summary, conventional paired-test audit, analysis manifest, and
  the figures generated from those records.

code/
  The predictor, native Gait120 preprocessing, accuracy-path, timing-control,
  level-walking motion-matching, reference-centered MuJoCo evaluation, and final
  statistical-analysis source files. The final physics entry point is
  mocap_phys_eval/run_gait120_level_walking_v4.py; the final analysis entry point
  is gait120_v4.py. gait120_conventional_paired_statistics.py reproduces the
  participant-level paired tests reported in the manuscript, and
  gait120_submission_figures_original_style.py reproduces the revised figures.
  requirements.txt lists the Python packages used by the project.

Primary integrity records
-------------------------

The physics analysis manifest records the SHA-256 digest of the complete
physics summary and all analysis inputs. audit_summary.json records the passed
cardinality, balance-loss, mapping, interpolation, and participant-level checks.
All participant inference treats a participant, not a window, as the unit.
