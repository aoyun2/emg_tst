Additional file 1: representative MuJoCo simulation recordings

Each MP4 is an actual one-second recording from the final 100% training-data
simulation panel. The three views are arranged from left to right as follows:

1. unmodified level-walking reference;
2. residual-fusion prediction; and
3. the same kinematic model without sEMG.

The magenta right leg received the predicted knee target. The eight panel
indices (0, 11, 22, 33, 44, 55, 66, and 77) were selected at evenly spaced
positions before simulation outcomes were examined. No recording was selected
because it looked better or produced a preferred result.

Files are named by panel index and the Gait120 query identifier. Videos are
H.264 MP4 files at 1440 x 360 pixels and approximately 1.02 seconds each.
